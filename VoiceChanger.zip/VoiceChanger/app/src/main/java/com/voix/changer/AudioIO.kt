package com.voix.changer
import android.content.Context
import android.media.*
import android.net.Uri
import java.io.*
import java.nio.*

object AudioIO {
    fun toShorts(bytes: ByteArray, ch: Int): ShortArray {
        val sb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val a = ShortArray(sb.remaining()); sb.get(a)
        if (ch <= 1) return a
        return ShortArray(a.size / ch) { i -> var s = 0; for (c in 0 until ch) s += a[i * ch + c]; (s / ch).toShort() }
    }

    /** Décode MP3/M4A/WAV... en PCM mono 16 bits. */
    fun decode(ctx: Context, uri: Uri): Pair<ShortArray, Int> {
        val ex = MediaExtractor(); ex.setDataSource(ctx, uri, null)
        val ti = (0 until ex.trackCount).first { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/") }
        ex.selectTrack(ti)
        val f = ex.getTrackFormat(ti)
        val codec = MediaCodec.createDecoderByType(f.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(f, null, null, 0); codec.start()
        var rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val bos = ByteArrayOutputStream(); val info = MediaCodec.BufferInfo()
        var inDone = false; var outDone = false
        while (!outDone) {
            if (!inDone) {
                val i = codec.dequeueInputBuffer(10000)
                if (i >= 0) {
                    val n = ex.readSampleData(codec.getInputBuffer(i)!!, 0)
                    if (n < 0) { codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                    else { codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance() }
                }
            }
            val o = codec.dequeueOutputBuffer(info, 10000)
            if (o >= 0) {
                val b = ByteArray(info.size); codec.getOutputBuffer(o)!!.get(b); bos.write(b)
                codec.releaseOutputBuffer(o, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
            } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val nf = codec.outputFormat
                rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE); ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            }
        }
        codec.stop(); codec.release(); ex.release()
        return toShorts(bos.toByteArray(), ch) to rate
    }

    fun writeWav(file: File, pcm: ShortArray, rate: Int) {
        val len = pcm.size * 2
        val bb = ByteBuffer.allocate(44 + len).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()).putInt(36 + len).put("WAVEfmt ".toByteArray())
        bb.putInt(16).putShort(1).putShort(1).putInt(rate).putInt(rate * 2).putShort(2).putShort(16)
        bb.put("data".toByteArray()).putInt(len)
        for (s in pcm) bb.putShort(s)
        file.writeBytes(bb.array())
    }
}
