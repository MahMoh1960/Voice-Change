package com.voix.changer
import kotlin.math.*

/** Changement de hauteur de haute qualité (WSOLA + rééchantillonnage), pour les fichiers. */
object Wsola {
    fun shift(x: FloatArray, r: Float): FloatArray {
        val n = 1024; val hs = n / 2; val tol = n / 4
        if (x.size < n * 4) return x
        val win = FloatArray(n) { (0.5 - 0.5 * cos(2.0 * PI * it / n)).toFloat() }
        val outLen = (x.size * r).toInt()
        val y = FloatArray(outLen + 2 * n)
        var prev = 0; var m = 0
        while (true) {
            val syn = m * hs
            if (syn >= outLen) break
            var pos = 0
            if (m > 0) {
                val target = (syn / r).toInt()
                val tpl = prev + hs
                pos = target.coerceIn(0, x.size - n)
                if (tpl + n <= x.size) {
                    var best = -1e30f
                    var d = max(0, target - tol); val hi = min(x.size - n, target + tol)
                    while (d <= hi) {
                        var c = 0f; var k = 0
                        while (k < n) { c += x[d + k] * x[tpl + k]; k += 4 }
                        if (c > best) { best = c; pos = d }
                        d += 2
                    }
                }
            }
            if (pos + n > x.size) break
            for (k in 0 until n) y[syn + k] += x[pos + k] * win[k]
            prev = pos; m++
        }
        return FloatArray(x.size) { i ->
            val p = i * r; val i0 = p.toInt()
            if (i0 + 1 >= y.size) 0f else { val f = p - i0; y[i0] * (1 - f) + y[i0 + 1] * f }
        }
    }
}

/** Filtre anti-grondement (80 Hz) + équilibre graves/aigus (t>0 plus clair, t<0 plus chaud). */
class Tone(rate: Int) {
    private val a = (1.0 - exp(-2 * PI * 1500 / rate)).toFloat()
    private val b = (1.0 - exp(-2 * PI * 80 / rate)).toFloat()
    private var lp = 0f; private var hp = 0f
    fun p(x: Float, t: Float): Float {
        hp += b * (x - hp); val v = x - hp
        lp += a * (v - lp)
        return lp * (1 - t * 0.5f) + (v - lp) * (1 + t * 0.5f)
    }
}
