package com.voix.changer
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.os.IBinder
import kotlin.math.*

/** Voix en direct (micro -> voix changée -> haut-parleur), maintenue en arrière-plan. */
class LiveService : Service() {
    companion object {
        @Volatile var ratio = 1f
        @Volatile var robot = false
        @Volatile var tilt = 0f
        @Volatile var running = false
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "stop") { running = false; return START_NOT_STICKY }
        if (running) return START_NOT_STICKY
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("live", "Voix en direct", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "live").setContentTitle("Change-Voix actif")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        running = true
        Thread { loop(); stopSelf() }.start()
        return START_NOT_STICKY
    }

    private fun loop() {
        val r = 44100
        val min = max(AudioRecord.getMinBufferSize(r, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT),
            AudioTrack.getMinBufferSize(r, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT))
        val ar = AudioRecord(MediaRecorder.AudioSource.MIC, r, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2)
        val at = AudioTrack.Builder()
            .setAudioFormat(AudioFormat.Builder().setSampleRate(r).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(min * 2).build()
        val tn = Tone(r); val s = PitchShifter(ratio); val b = ShortArray(1024); var t = 0L
        ar.startRecording(); at.play()
        while (running) {
            val n = ar.read(b, 0, b.size); s.ratio = ratio
            for (k in 0 until max(n, 0)) {
                var v = tn.p(s.process(b[k] / 32768f), tilt)
                if (robot) v *= 0.5f + 0.5f * sin(2.0 * PI * 50 * (t++) / r).toFloat()
                b[k] = (v.coerceIn(-1f, 1f) * 32767).toInt().toShort()
            }
            if (n > 0) at.write(b, 0, n)
        }
        ar.stop(); ar.release(); at.stop(); at.release()
    }
}
