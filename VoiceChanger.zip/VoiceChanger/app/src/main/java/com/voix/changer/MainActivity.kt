package com.voix.changer
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.media.*
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.content.FileProvider
import java.io.*
import kotlin.math.*

class Th(val n: String, val bg: Int, val fg: Int, val ac: Int)

class MainActivity : Activity() {
    private var pcm = ShortArray(0)
    private var rate = 44100
    private var ratio: Float get() = LiveService.ratio; set(v) { LiveService.ratio = v }
    private var robot: Boolean get() = LiveService.robot; set(v) { LiveService.robot = v }
    @Volatile private var recording = false
    private var number = ""
    private var track: AudioTrack? = null
    private lateinit var status: TextView
    private lateinit var label: TextView
    private lateinit var bar: SeekBar
    private lateinit var scroll: ScrollView
    private val texts = ArrayList<TextView>()
    private val buttons = ArrayList<Button>()
    private val spins = ArrayList<Spinner>()
    private val voices = listOf("Homme" to -3, "Femme" to 4, "Garçon" to 2, "Fille" to 5,
        "Fillette" to 8, "Vieil homme" to -5, "Voix grave" to -8, "Robot" to 0)
    private val tilts = listOf(-0.2f, 0.4f, 0.2f, 0.5f, 0.6f, -0.4f, -0.5f, 0f)
    private val themes = listOf(
        Th("Sombre", 0xFF121212.toInt(), 0xFFEEEEEE.toInt(), 0xFF4DB6AC.toInt()),
        Th("Jaune sur bleu nuit", 0xFF0A1633.toInt(), 0xFFFFD60A.toInt(), 0xFFFFD60A.toInt()),
        Th("Vert sur noir", 0xFF000000.toInt(), 0xFF39FF14.toInt(), 0xFF39FF14.toInt()),
        Th("Rose sur violet", 0xFF2B0A3D.toInt(), 0xFFFF8AD8.toInt(), 0xFFFF8AD8.toInt()),
        Th("Océan", 0xFF062B3A.toInt(), 0xFFE0F7FA.toInt(), 0xFF00BCD4.toInt()),
        Th("Orange sur marron", 0xFF2A1608.toInt(), 0xFFFFB74D.toInt(), 0xFFFF9800.toInt()),
        Th("Clair", 0xFFFFFFFF.toInt(), 0xFF111111.toInt(), 0xFF1976D2.toInt()))
    private var cur = themes[0]

    private fun adapter(items: List<String>) = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items) {
        override fun getView(p: Int, c: View?, g: ViewGroup): View = super.getView(p, c, g).also { (it as TextView).setTextColor(cur.fg) }
        override fun getDropDownView(p: Int, c: View?, g: ViewGroup): View = super.getDropDownView(p, c, g).also {
            (it as TextView).setTextColor(cur.fg); it.setBackgroundColor(cur.bg) }
    }

    private fun applyTheme(i: Int) {
        cur = themes[i]
        scroll.setBackgroundColor(cur.bg); window.statusBarColor = cur.bg; window.navigationBarColor = cur.bg
        texts.forEach { it.setTextColor(cur.fg) }
        buttons.forEach { it.backgroundTintList = ColorStateList.valueOf(cur.ac); it.setTextColor(cur.bg) }
        bar.progressTintList = ColorStateList.valueOf(cur.ac); bar.thumbTintList = ColorStateList.valueOf(cur.ac)
        spins.forEach { (it.adapter as ArrayAdapter<*>).notifyDataSetChanged() }
        getSharedPreferences("p", 0).edit().putInt("theme", i).apply()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        scroll = ScrollView(this).apply { isFillViewport = true; addView(col) }
        setContentView(scroll)
        status = TextView(this).apply { text = "Prêt." }
        label = TextView(this).apply { text = "Hauteur : 0 demi-tons" }
        texts += listOf(status, label)
        val voiceSpin = Spinner(this).apply { adapter = adapter(voices.map { it.first }) }
        val themeSpin = Spinner(this).apply { adapter = adapter(themes.map { "Thème : " + it.n }) }
        spins += listOf(voiceSpin, themeSpin)
        bar = SeekBar(this).apply { max = 24; progress = 12 }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                val st = p - 12; ratio = 2f.pow(st / 12f); label.text = "Hauteur : $st demi-tons"
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        voiceSpin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, i: Int, id: Long) {
                bar.progress = voices[i].second + 12; robot = voices[i].first == "Robot"; LiveService.tilt = tilts[i]
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        themeSpin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, i: Int, id: Long) = applyTheme(i)
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() }; buttons += this }
        listOf(themeSpin, voiceSpin, label, bar,
            btn("● Enregistrer / ■ Arrêter") { toggleRec() },
            btn("Importer un fichier audio") { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("audio/*"), 2) },
            btn("▶ Écouter avec la voix") { play() },
            btn("Partager / Exporter (WAV)") { share() },
            btn("Envoyer sur WhatsApp") { share("com.whatsapp") },
            btn("Direct micro (casque conseillé)") { toggleLive() },
            btn("Choisir un contact") { startActivityForResult(Intent(Intent.ACTION_PICK, Phone.CONTENT_URI), 3) },
            btn("📞 Appeler avec la voix changée") { callWithVoice() },
            status).forEach { col.addView(it) }
        val saved = getSharedPreferences("p", 0).getInt("theme", 1)
        themeSpin.setSelection(saved); applyTheme(saved)
    }

    private fun say(t: String) = runOnUiThread { status.text = t }

    private fun toggleRec() {
        if (recording) { recording = false; return }
        recording = true; say("Enregistrement… (rappuyez pour arrêter)")
        Thread {
            val min = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val ar = AudioRecord(MediaRecorder.AudioSource.MIC, 44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2)
            val bos = ByteArrayOutputStream(); val buf = ByteArray(min)
            ar.startRecording()
            while (recording) { val n = ar.read(buf, 0, buf.size); if (n > 0) bos.write(buf, 0, n) }
            ar.stop(); ar.release()
            pcm = AudioIO.toShorts(bos.toByteArray(), 1); rate = 44100
            say("Enregistré : ${pcm.size / rate} s")
        }.start()
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        val uri = d?.data ?: return
        if (rc == 3) {
            contentResolver.query(uri, arrayOf(Phone.NUMBER, Phone.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) { number = it.getString(0); say("Contact : ${it.getString(1)} ($number)") }
            }
            return
        }
        say("Chargement…")
        Thread {
            try { val (a, r) = AudioIO.decode(this, uri); pcm = a; rate = r; say("Importé : ${a.size / r} s") }
            catch (e: Exception) { say("Erreur : ${e.message}") }
        }.start()
    }

    private fun render(): ShortArray {
        val x = FloatArray(pcm.size) { pcm[it] / 32768f }
        val y = if (abs(ratio - 1f) < 0.01f) x else Wsola.shift(x, ratio)
        val tn = Tone(rate); var peak = 0.001f
        for (i in y.indices) {
            var v = tn.p(y[i], LiveService.tilt)
            if (robot) v *= 0.5f + 0.5f * sin(2.0 * PI * 50 * i / rate).toFloat()
            y[i] = v; peak = max(peak, abs(v))
        }
        val g = 0.92f / peak
        return ShortArray(y.size) { ((y[it] * g).coerceIn(-1f, 1f) * 32767).toInt().toShort() }
    }

    private fun withRender(cb: (ShortArray) -> Unit) {
        if (pcm.isEmpty()) { say("Enregistrez ou importez d'abord."); return }
        say("Traitement en cours…")
        Thread { val o = render(); runOnUiThread { cb(o); say("Terminé.") } }.start()
    }

    private fun play() = withRender { out ->
        track?.release()
        track = AudioTrack.Builder()
            .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(out.size * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
        track!!.write(out, 0, out.size); track!!.play()
    }

    private fun share(pkg: String? = null) = withRender { out ->
        val f = File(cacheDir, "voix.wav"); AudioIO.writeWav(f, out, rate)
        val uri = FileProvider.getUriForFile(this, "com.voix.changer.fp", f)
        val i = Intent(Intent.ACTION_SEND).setType("audio/wav")
            .putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        if (pkg != null) {
            try { startActivity(i.setPackage(pkg)) } catch (e: Exception) { say("WhatsApp introuvable.") }
        } else startActivity(Intent.createChooser(i, "Partager"))
    }

    private fun toggleLive() {
        if (LiveService.running) { startService(Intent(this, LiveService::class.java).setAction("stop")); say("Direct arrêté.") }
        else { startForegroundService(Intent(this, LiveService::class.java)); say("Direct activé.") }
    }

    private fun callWithVoice() {
        if (number.isEmpty()) { say("Choisissez d'abord un contact."); return }
        if (!LiveService.running) startForegroundService(Intent(this, LiveService::class.java))
        say("Direct activé. Lancez l'appel, puis mettez le haut-parleur.")
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))
    }
}
