package com.voix.changer
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.*
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.core.content.FileProvider
import java.io.*
import kotlin.math.*

class MainActivity : Activity() {
    private var pcm = ShortArray(0)
    private var rate = 44100
    @Volatile private var ratio = 1f
    @Volatile private var robot = false
    @Volatile private var recording = false
    @Volatile private var live = false
    private var track: AudioTrack? = null
    private lateinit var status: TextView
    private lateinit var label: TextView
    private lateinit var bar: SeekBar
    private val voices = listOf("Homme" to -3, "Femme" to 4, "Garçon" to 2, "Fille" to 5,
        "Fillette" to 8, "Vieil homme" to -5, "Voix grave" to -8, "Robot" to 0)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 40, 40, 40) }
        setContentView(ScrollView(this).apply { addView(col) })
        status = TextView(this).apply { text = "Prêt." }
        label = TextView(this)
        val spin = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, voices.map { it.first }) }
        bar = SeekBar(this).apply { max = 24; progress = 12 }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                val st = p - 12; ratio = 2f.pow(st / 12f); label.text = "Hauteur : $st demi-tons"
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        spin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, i: Int, id: Long) {
                bar.progress = voices[i].second + 12; robot = voices[i].first == "Robot"
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        label.text = "Hauteur : 0 demi-tons"
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        listOf(spin, label, bar,
            btn("● Enregistrer / ■ Arrêter") { toggleRec() },
            btn("Importer un fichier audio") { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("audio/*"), 2) },
            btn("▶ Écouter avec la voix") { play() },
            btn("Partager / Exporter (WAV)") { share() },
            btn("Direct micro (casque obligatoire)") { toggleLive() },
            status).forEach { col.addView(it) }
    }

    private fun say(t: String) = runOnUiThread { status.text = t }

    private fun toggleRec() {
        if (recording) { recording = false; return }
        recording = true; say("Enregistrement… (rappuyez pour arrêter)")
        Thread {
            val min = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val ar = AudioRecord(MediaRecorder.AudioSource.MIC, 44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2)
            val bos = ByteArrayOutputStream(); val buf = ByteArray(min)
            ar.startRecording()
            while (recording) { val n = ar.read(buf, 0, buf.size); if (n > 0) bos.write(buf, 0, n) }
            ar.stop(); ar.release()
            pcm = AudioIO.toShorts(bos.toByteArray(), 1); rate = 44100
            say("Enregistré : ${pcm.size / rate} s")
        }.start()
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        val uri = d?.data ?: return
        say("Chargement…")
        Thread {
            try { val (a, r) = AudioIO.decode(this, uri); pcm = a; rate = r; say("Importé : ${a.size / r} s") }
            catch (e: Exception) { say("Erreur : ${e.message}") }
        }.start()
    }

    private fun render(): ShortArray {
        val s = PitchShifter(ratio)
        return ShortArray(pcm.size) { i ->
            var v = s.process(pcm[i] / 32768f)
            if (robot) v *= 0.5f + 0.5f * sin(2.0 * PI * 50 * i / rate).toFloat()
            (v.coerceIn(-1f, 1f) * 32767).toInt().toShort()
        }
    }

    private fun play() {
        if (pcm.isEmpty()) { say("Enregistrez ou importez d'abord."); return }
        val out = render()
        track?.release()
        track = AudioTrack.Builder()
            .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(out.size * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
        track!!.write(out, 0, out.size); track!!.play()
    }

    private fun share() {
        if (pcm.isEmpty()) { say("Rien à exporter."); return }
        val f = File(cacheDir, "voix.wav"); AudioIO.writeWav(f, render(), rate)
        val uri = FileProvider.getUriForFile(this, "com.voix.changer.fp", f)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("audio/wav")
            .putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Partager"))
    }

    private fun toggleLive() {
        if (live) { live = false; return }
        live = true; say("Direct activé. Utilisez un casque !")
        Thread {
            val r = 44100
            val min = max(AudioRecord.getMinBufferSize(r, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT),
                AudioTrack.getMinBufferSize(r, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT))
            val ar = AudioRecord(MediaRecorder.AudioSource.MIC, r, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2)
            val at = AudioTrack.Builder()
                .setAudioFormat(AudioFormat.Builder().setSampleRate(r).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(min * 2).build()
            val s = PitchShifter(ratio); val b = ShortArray(1024); var t = 0L
            ar.startRecording(); at.play()
            while (live) {
                val n = ar.read(b, 0, b.size); s.ratio = ratio
                for (i in 0 until n) {
                    var v = s.process(b[i] / 32768f)
                    if (robot) v *= 0.5f + 0.5f * sin(2.0 * PI * 50 * (t++) / r).toFloat()
                    b[i] = (v.coerceIn(-1f, 1f) * 32767).toInt().toShort()
                }
                at.write(b, 0, n)
            }
            ar.stop(); ar.release(); at.stop(); at.release(); say("Direct arrêté.")
        }.start()
    }
}
