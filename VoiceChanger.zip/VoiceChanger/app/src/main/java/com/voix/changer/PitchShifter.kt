package com.voix.changer
import kotlin.math.*

/** Pitch shifter temps réel (deux têtes de lecture croisées). ratio>1 = plus aigu. */
class PitchShifter(var ratio: Float) {
    private val n = 8192
    private val win = 1764f
    private val buf = FloatArray(n)
    private var w = 0
    private var phase = 0f

    fun process(x: Float): Float {
        buf[w] = x
        var out = 0f
        for (k in 0..1) {
            var p = phase + 0.5f * k
            if (p >= 1f) p -= 1f
            val pos = w - (p * win + 2f)
            val i0f = floor(pos)
            val frac = pos - i0f
            val i0 = ((i0f.toInt() % n) + n) % n
            val s = buf[i0] * (1 - frac) + buf[(i0 + 1) % n] * frac
            val g = sin(PI.toFloat() * p).let { it * it }
            out += s * g
        }
        phase += (1f - ratio) / win
        while (phase < 0f) phase += 1f
        while (phase >= 1f) phase -= 1f
        w = (w + 1) % n
        return out
    }
}
